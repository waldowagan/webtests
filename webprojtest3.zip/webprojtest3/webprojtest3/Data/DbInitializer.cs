﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using webprojtest3.Models;

namespace webprojtest3.Data
{
    public class DbInitializer
    {
        public static void Initialize(GymContext context)
        {
            context.Database.EnsureCreated();

            // Look for any students.
            if (context.Students.Any())
            {
                return;   // DB has been seeded
            }

            var students = new Student[]
            {
            new Student{StudentID="00001", f_Name="Waldo",l_Name="Wagan",email = "test@gmail.com", phone_No = "021093293", emergency_Contact_Name="Jacy", emergency_Contact_No = "0219329" },
            new Student{StudentID="00002", f_Name="Waldo",l_Name="Wagan",email = "test@gmail.com", phone_No = "021093293", emergency_Contact_Name="Jacy", emergency_Contact_No = "0219329" }
            };
            foreach (Student s in students)
            {
                context.Students.Add(s);
            }
            context.SaveChanges();
        }
    }
}
